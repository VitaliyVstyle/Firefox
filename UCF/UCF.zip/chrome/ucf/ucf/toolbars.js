var toolbars = {
    externalToolbars: [],
    eventListeners: new Map(),
    get main_popup() {
        delete this.main_popup;
        return this.main_popup = document.querySelector("#mainPopupSet");
    },
    init() {
        var navtoolbox = this.navtoolbox = window.gNavToolbox || document.querySelector("#navigator-toolbox");
        if (!navtoolbox) return;
        var { prefs } = UcfPrefs, toolbarcreate = false, t_autohide = false, v_autohide = false;
        var l10nPath = "ucf/locales", l10nFile = "toolbars.ftl";
        if (prefs.t_enable) {
            try {
                let topbar = this.topbar = document.createXULElement("toolbar");
                UcfPrefs.getLocalization(l10nPath, l10nFile).formatValue("ucf-additional-top-bar").then(val => {
                    topbar.setAttribute("toolbarname", val);
                });
                topbar.id = "ucf-additional-top-bar";
                topbar.className = "chromeclass-toolbar-additional chromeclass-toolbar customization-target browser-toolbar";
                topbar.setAttribute("context", "toolbar-context-menu");
                topbar.setAttribute("mode", "icons");
                topbar.setAttribute("accesskey", "");
                topbar.setAttribute("key", "");
                topbar.setAttribute("iconsize", "small");
                topbar.setAttribute("fullscreentoolbar", "true");
                topbar.setAttribute("customizable", "true");
                if (prefs.t_collapsed) topbar.collapsed = true;
                let sel = prefs.t_next_navbar ? "#nav-bar" : ":scope > :nth-last-child(1 of toolbar:not(#notifications-toolbar))";
                if (prefs.t_autohide) {
                    let tcontainer = this.tcontainer = document.createXULElement("vbox");
                    tcontainer.id = "ucf-additional-top-container";
                    tcontainer.className = "chromeclass-toolbar-additional chromeclass-toolbar";
                    tcontainer.setAttribute("topautohide", "true");
                    let topbox = this.topbox = document.createElementNS("http://www.w3.org/1999/xhtml", "html:div");
                    topbox.id = "ucf-additional-top-box";
                    topbox.setAttribute("topautohide", "true");
                    topbox.setAttribute("popover", "manual");
                    topbox.append(topbar);
                    tcontainer.append(topbox);
                    navtoolbox.querySelector(sel).after(tcontainer);
                    topbox.showPopover();
                    document.documentElement.setAttribute("v_top_bar_autohide", "true");
                    t_autohide = true;
                } else navtoolbox.querySelector(sel).after(topbar);
                toolbarcreate = true;
            } catch { }
        }
        var externalToolbars = false;
        if (prefs.v_enable) {
            try {
                let vcontainer = this.vcontainer = document.createXULElement("vbox");
                vcontainer.id = "ucf-additional-vertical-container";
                vcontainer.className = "chromeclass-toolbar-additional chromeclass-toolbar";
                vcontainer.setAttribute("vertautohide", `${prefs.v_autohide}`);
                vcontainer.setAttribute("v_vertical_bar_start", `${prefs.v_bar_start}`);
                vcontainer.hidden = true;
                let verticalbox = this.verticalbox = document.createElementNS("http://www.w3.org/1999/xhtml", "html:div");
                verticalbox.id = "ucf-additional-vertical-box";
                verticalbox.setAttribute("vertautohide", `${prefs.v_autohide}`);
                verticalbox.setAttribute("v_vertical_bar_start", `${prefs.v_bar_start}`);
                verticalbox.setAttribute("flex", "1");
                let verticalbar = this.verticalbar = document.createXULElement("toolbar");
                UcfPrefs.getLocalization(l10nPath, l10nFile).formatValue("ucf-additional-vertical-bar").then(val => {
                    verticalbar.setAttribute("toolbarname", val);
                });
                verticalbar.id = "ucf-additional-vertical-bar";
                verticalbar.className = "chromeclass-toolbar-additional chromeclass-toolbar customization-target browser-toolbar";
                verticalbar.setAttribute("toolboxid", "navigator-toolbox");
                verticalbar.setAttribute("context", "toolbar-context-menu");
                verticalbar.setAttribute("mode", "icons");
                verticalbar.setAttribute("iconsize", "small");
                verticalbar.setAttribute("accesskey", "");
                verticalbar.setAttribute("key", "");
                verticalbar.setAttribute("orient", "vertical");
                verticalbar.setAttribute("fullscreentoolbar", `${prefs.v_fullscreen}`);
                verticalbar.setAttribute("customizable", "true");
                if (prefs.v_collapsed) verticalbar.collapsed = true;
                verticalbox.append(verticalbar);
                vcontainer.append(verticalbox);
                let browser = document.querySelector("hbox#browser");
                if (prefs.v_bar_start) {
                    browser.prepend(vcontainer);
                    document.documentElement.setAttribute("v_vertical_bar_start", "true");
                } else {
                    browser.append(vcontainer);
                    document.documentElement.setAttribute("v_vertical_bar_start", "false");
                }
                if (prefs.v_autohide) {
                    verticalbox.setAttribute("popover", "manual");
                    verticalbox.showPopover();
                    document.documentElement.setAttribute("v_vertical_bar_autohide", "true");
                    v_autohide = true;
                }
                this.addListener("navtoolbox_beforecustomization", navtoolbox, "beforecustomization", this);
                this.externalToolbars.push(verticalbar);
                externalToolbars = true;
                toolbarcreate = true;
            } catch { }
        }
        if (prefs.b_enable) {
            try {
                let bottombar = this.bottombar = document.createXULElement("toolbar");
                bottombar.id = "ucf-additional-bottom-bar";
                bottombar.className = "chromeclass-toolbar-additional chromeclass-toolbar customization-target browser-toolbar";
                bottombar.setAttribute("toolboxid", "navigator-toolbox");
                bottombar.setAttribute("context", "toolbar-context-menu");
                bottombar.setAttribute("mode", "icons");
                bottombar.setAttribute("iconsize", "small");
                bottombar.setAttribute("accesskey", "");
                bottombar.setAttribute("key", "");
                bottombar.setAttribute("customizable", "true");
                if (prefs.b_collapsed) bottombar.collapsed = true;
                let closebutton = document.createXULElement("toolbarbutton");
                UcfPrefs.getLocalization(l10nPath, l10nFile).formatValues(["ucf-additional-bottom-bar", "ucf-additional-bottom-closebutton"]).then(arr => {
                    bottombar.setAttribute("toolbarname", arr[0]);
                    closebutton.setAttribute("tooltiptext", arr[1]);
                });
                closebutton.id = "ucf-additional-bottom-closebutton";
                closebutton.className = "close-icon closebutton";
                closebutton.setAttribute("removable", "false");
                this.addListener("closebutton_command", closebutton, "command", e => CustomizableUI.setToolbarVisibility("ucf-additional-bottom-bar", false));
                bottombar.append(closebutton);
                let bottombox = document.createXULElement("vbox");
                bottombox.id = "browser-bottombox";
                document.body.append(bottombox);
                bottombox.append(bottombar);
                this.externalToolbars.push(bottombar);
                externalToolbars = true;
                toolbarcreate = true;
            } catch { }
        }
        if (toolbarcreate) {
            this.addListener("window_toolbarvisibilitychange", window, "toolbarvisibilitychange", this);
            setUnloadMap(Symbol(), this.destructor, this);
            delayedStartupPromise.then(() => {
                Cu.evalInSandbox(UcfPrefs._viewToolbars(window, externalToolbars), sandboxWinSysPrincipal);
                if (t_autohide) this.top_autohide.init();
                if (v_autohide) this.vert_autohide.init();
                if (!externalToolbars) return;
                for (let { type, listenerObject: listener, capturing } of Services.els.getListenerInfoFor(navtoolbox)) {
                    if (typeof listener === "function" && Cu.getFunctionSourceLocation(listener)
                        .filename === "chrome://browser/content/navigator-toolbox.js")
                        for (let elm of this.externalToolbars)
                            this.addListener(Symbol(), elm, type, listener, capturing);
                }
            });
        }
    },
    addListener(key, elm, type, listener, capturing = false) {
        elm.addEventListener(type, listener, capturing);
        this.eventListeners.set(key, { elm, type, listener, capturing });
    },
    delListener(key) {
        var { eventListeners } = this, getkey = eventListeners.get(key);
        if (!getkey) return;
        var { elm, type, listener, capturing } = getkey;
        elm.removeEventListener(type, listener, capturing);
        eventListeners.delete(key);
    },
    destructor() {
        var { prefs } = UcfPrefs;
        if (prefs.t_enable && prefs.t_autohide) this.top_autohide.destructor();
        if (prefs.v_enable && prefs.v_autohide) this.vert_autohide.destructor();
        this.eventListeners.forEach(({ elm, type, listener, capturing }) => elm.removeEventListener(type, listener, capturing));
    },
    handleEvent(e) {
        this[e.type](e);
    },
    toolbarvisibilitychange(e) {
        switch (e.target) {
            case this.verticalbar:
                UcfPrefs.setPrefs("v_collapsed", this.verticalbar.collapsed);
                break;
            case this.topbar:
                UcfPrefs.setPrefs("t_collapsed", this.topbar.collapsed);
                break;
            case this.bottombar:
                UcfPrefs.setPrefs("b_collapsed", this.bottombar.collapsed);
                break;
        }
    },
    beforecustomization() {
        this.verticalbar.removeAttribute("orient");
        var { navtoolbox } = this;
        navtoolbox.querySelector(":scope > toolbar:last-of-type").after(this.verticalbar);
        this.addListener("navtoolbox_aftercustomization", navtoolbox, "aftercustomization", this);
    },
    aftercustomization() {
        var { verticalbar } = this;
        verticalbar.setAttribute("orient", "vertical");
        this.verticalbox.append(verticalbar);
        this.delListener("navtoolbox_aftercustomization");
    },
    top_autohide: {
        isVisible: false,
        isMouseOver: false,
        isPopupOpen: false,
        showTimer: null,
        hideTimer: null,
        init() {
            var tabpanels = this.tabpanels = gBrowser.tabpanels;
            if (!tabpanels) return;
            this.eventListeners = new Map();
            var hoverbox = this.hoverbox = document.querySelector(UcfPrefs.prefs.t_hoversel) || document.querySelector("#nav-bar");
            var { navtoolbox, topbar } = toolbars;
            this.addListener("hoverbox_mouseenter", hoverbox, "mouseenter", this);
            this.addListener("hoverbox_mouseleave", hoverbox, "mouseleave", this);
            this.addListener("hoverbox_dragenter", hoverbox, "dragenter", this);
            this.addListener("navtoolbox_popupshown", navtoolbox, "popupshown", this);
            this.addListener("navtoolbox_popuphidden", navtoolbox, "popuphidden", this);
            this.addListener("navtoolbox_beforecustomization", navtoolbox, "beforecustomization", this);
            setTimeout(() => {
                document.documentElement.style.setProperty("--v-top-bar-height", `${Math.round(topbar.getBoundingClientRect().height)}px`);
            }, 0);
        },
        handleEvent(e) {
            this[e.type](e);
        },
        addListener(key, elm, type, listener) {
            elm.addEventListener(type, listener);
            this.eventListeners.set(key, { elm, type, listener });
        },
        delListener(key) {
            var { eventListeners } = this, getkey = eventListeners.get(key);
            if (!getkey) return;
            var { elm, type, listener } = getkey;
            elm.removeEventListener(type, listener);
            eventListeners.delete(key);
        },
        destructor() {
            this.eventListeners.forEach(({ elm, type, listener }) => {
                elm.removeEventListener(type, listener);
            });
        },
        beforecustomization() {
            var { navtoolbox, tcontainer, topbar } = toolbars;
            tcontainer.after(topbar);
            this.addListener("navtoolbox_aftercustomization", navtoolbox, "aftercustomization", this);
        },
        aftercustomization() {
            var { topbox, topbar } = toolbars;
            topbox.append(topbar);
            this.delListener("navtoolbox_aftercustomization");
        },
        popupshown(e) {
            if (e.target.localName === "tooltip" || ((e.currentTarget == toolbars.main_popup) && e.target.id !== "customizationui-widget-panel")) return;
            this.isPopupOpen = true;
        },
        popuphidden(e) {
            if (e.target.localName === "tooltip" || ((e.currentTarget == toolbars.main_popup) && e.target.id !== "customizationui-widget-panel")) return;
            this.isPopupOpen = false;
            this.hideBar();
        },
        mouseenter(e) {
            switch (e.currentTarget) {
                case this.hoverbox:
                    this.isMouseOver = true;
                    if (!this.isVisible && !this.isPopupOpen) this.showBar();
                    break;
                case toolbars.topbar:
                    this.isMouseOver = true;
                    break;
                default:
                    this.isMouseOver = false;
                    this.hideBar();
                    break;
            }
        },
        dragenter(e) {
            switch (e.currentTarget) {
                case this.hoverbox:
                    if (!this.isVisible) this.showBar();
                    break;
                default:
                    this.hideBar(true);
                    break;
            }
        },
        mouseleave() {
            clearTimeout(this.showTimer);
        },
        mouseup(e) {
            if (e.button) return;
            this.hideBar(true);
        },
        showBar() {
            clearTimeout(this.showTimer);
            this.showTimer = setTimeout(() => {
                this.isVisible = true;
                var docElm = document.documentElement;
                var { tabpanels } = this;
                var { topbar, topbox, navtoolbox, main_popup } = toolbars;
                var tbrect = topbar.getBoundingClientRect();
                var height = tbrect.height;
                var overlaps = Math.round(tbrect.bottom + height - navtoolbox.getBoundingClientRect().bottom);
                topbox.setAttribute("v_top_bar_visible", "true");
                docElm.setAttribute("v_top_bar_visible", "true");
                if (overlaps > 0) {
                    docElm.style.setProperty("--v-top-bar-overlaps", `${overlaps}px`);
                    docElm.setAttribute("v_top_bar_overlaps", "true");
                }
                docElm.style.setProperty("--v-top-bar-height", `${Math.round(height)}px`);
                this.addListener("tabpanels_mouseenter", tabpanels, "mouseenter", this);
                this.addListener("tabpanels_dragenter", tabpanels, "dragenter", this);
                this.addListener("tabpanels_mouseup", tabpanels, "mouseup", this);
                this.addListener("topbar_mouseenter", topbar, "mouseenter", this);
                this.addListener("topbar_popupshown", topbar, "popupshown", this);
                this.addListener("topbar_popuphidden", topbar, "popuphidden", this);
                this.addListener("main_popup_popupshown", main_popup, "popupshown", this);
                this.addListener("main_popup_popuphidden", main_popup, "popuphidden", this);
            }, UcfPrefs.prefs.t_showdelay);
        },
        hideBar(nodelay) {
            clearTimeout(this.hideTimer);
            var onTimeout = () => {
                if (this.isPopupOpen || this.isMouseOver) return;
                var docElm = document.documentElement;
                var { topbox } = toolbars;
                this.delListener("tabpanels_mouseenter");
                this.delListener("tabpanels_dragenter");
                this.delListener("tabpanels_mouseup");
                this.delListener("topbar_mouseenter");
                this.delListener("topbar_popupshown");
                this.delListener("topbar_popuphidden");
                this.delListener("main_popup_popupshown");
                this.delListener("main_popup_popuphidden");
                topbox.setAttribute("v_top_bar_visible", "false");
                docElm.setAttribute("v_top_bar_visible", "false");
                docElm.setAttribute("v_top_bar_overlaps", "false");
                docElm.style.setProperty("--v-top-bar-overlaps", `${0}px`);
                this.isVisible = false;
            };
            if (!nodelay) this.hideTimer = setTimeout(onTimeout, UcfPrefs.prefs.t_hidedelay);
            else onTimeout();
        },
    },
    vert_autohide: {
        isVisible: false,
        isMouseSidebar: false,
        isMouseOver: false,
        isPopupOpen: false,
        showTimer: null,
        hideTimer: null,
        init() {
            var tabpanels = this.tabpanels = gBrowser.tabpanels;
            var sidebarbox = this.sidebarbox = document.querySelector("#sidebar-box");
            this.sidebar_tabs = document.querySelector("#st_toolbox");
            if (!tabpanels || !sidebarbox) return;
            this.eventListeners = new Map();
            var { verticalbox, verticalbar } = toolbars;
            this.addListener("verticalbox_mouseenter", verticalbox, "mouseenter", this);
            this.addListener("verticalbox_mouseleave", verticalbox, "mouseleave", this);
            this.addListener("verticalbox_dragenter", verticalbox, "dragenter", this);
            setTimeout(() => {
                document.documentElement.style.setProperty("--v-vertical-bar-width", `${Math.round(verticalbar.getBoundingClientRect().width)}px`);
            }, 0);
        },
        handleEvent(e) {
            this[e.type](e);
        },
        addListener(key, elm, type, listener) {
            elm.addEventListener(type, listener);
            this.eventListeners.set(key, { elm, type, listener });
        },
        delListener(key) {
            var { eventListeners } = this, getkey = eventListeners.get(key);
            if (!getkey) return;
            var { elm, type, listener } = getkey;
            elm.removeEventListener(type, listener);
            eventListeners.delete(key);
        },
        destructor() {
            this.eventListeners.forEach(({ elm, type, listener }) => {
                elm.removeEventListener(type, listener);
            });
        },
        popupshown(e) {
            if (e.target.localName === "tooltip" || ((e.currentTarget == toolbars.main_popup) && e.target.id !== "customizationui-widget-panel")) return;
            this.isPopupOpen = true;
        },
        popuphidden(e) {
            if (e.target.localName === "tooltip" || ((e.currentTarget == toolbars.main_popup) && e.target.id !== "customizationui-widget-panel")) return;
            this.isPopupOpen = false;
            this.hideBar();
        },
        mouseenter(e) {
            switch (e.currentTarget) {
                case toolbars.verticalbox:
                    this.isMouseOver = true;
                    this.isMouseSidebar = false;
                    if (!this.isVisible) this.showBar();
                    break;
                case toolbars.verticalbar:
                    this.isMouseOver = true;
                    this.isMouseSidebar = false;
                    break;
                case this.sidebarbox:
                case this.sidebar_tabs:
                    this.isMouseOver = false;
                    this.isMouseSidebar = true;
                    this.hideBar();
                    break;
                default:
                    this.isMouseOver = this.isMouseSidebar = false;
                    this.hideBar();
                    break;
            }
        },
        dragenter(e) {
            switch (e.currentTarget) {
                case toolbars.verticalbox:
                    this.isMouseSidebar = false;
                    if (!this.isVisible) this.showBar();
                    break;
                default:
                    this.isMouseSidebar = false;
                    this.hideBar(true);
                    break;
            }
        },
        mouseleave() {
            clearTimeout(this.showTimer);
        },
        mouseup(e) {
            if (e.button) return;
            this.hideBar(true);
        },
        showBar() {
            clearTimeout(this.showTimer);
            this.showTimer = setTimeout(() => {
                this.isVisible = true;
                var docElm = document.documentElement;
                var { tabpanels, sidebarbox, sidebar_tabs } = this;
                var { verticalbar, verticalbox, main_popup } = toolbars;
                verticalbox.setAttribute("v_vertical_bar_visible", "visible");
                docElm.setAttribute("v_vertical_bar_visible", "visible");
                docElm.style.setProperty("--v-vertical-bar-width", `${Math.round(verticalbar.getBoundingClientRect().width)}px`);
                docElm.setAttribute("v_vertical_bar_sidebar", `${this.isMouseSidebar}`);
                if (UcfPrefs.prefs.v_mouseenter_sidebar) {
                    this.addListener("sidebarbox_mouseenter", sidebarbox, "mouseenter", this);
                    if (sidebar_tabs) this.addListener("sidebar_tabs_mouseenter", sidebar_tabs, "mouseenter", this);
                }
                this.addListener("tabpanels_mouseenter", tabpanels, "mouseenter", this);
                this.addListener("tabpanels_dragenter", tabpanels, "dragenter", this);
                this.addListener("tabpanels_mouseup", tabpanels, "mouseup", this);
                this.addListener("verticalbar_mouseenter", verticalbar, "mouseenter", this);
                this.addListener("verticalbar_popupshown", verticalbar, "popupshown", this);
                this.addListener("verticalbar_popuphidden", verticalbar, "popuphidden", this);
                this.addListener("main_popup_popupshown", main_popup, "popupshown", this);
                this.addListener("main_popup_popuphidden", main_popup, "popuphidden", this);
            }, UcfPrefs.prefs.v_showdelay);
        },
        hideBar(nodelay) {
            clearTimeout(this.hideTimer);
            var docElm = document.documentElement;
            var { verticalbox } = toolbars;
            verticalbox.setAttribute("v_vertical_bar_visible", "visible_hidden");
            docElm.setAttribute("v_vertical_bar_visible", "visible_hidden");
            docElm.setAttribute("v_vertical_bar_sidebar", `${this.isMouseSidebar}`);
            var onTimeout = () => {
                if (this.isPopupOpen || this.isMouseOver) return;
                this.delListener("tabpanels_mouseenter");
                this.delListener("tabpanels_dragenter");
                this.delListener("tabpanels_mouseup");
                this.delListener("verticalbar_mouseenter");
                this.delListener("verticalbar_popupshown");
                this.delListener("verticalbar_popuphidden");
                this.delListener("main_popup_popupshown");
                this.delListener("main_popup_popuphidden");
                verticalbox.setAttribute("v_vertical_bar_visible", "hidden");
                docElm.setAttribute("v_vertical_bar_visible", "hidden");
                docElm.setAttribute("v_vertical_bar_sidebar", "false");
                if (UcfPrefs.prefs.v_mouseenter_sidebar) {
                    this.delListener("sidebarbox_mouseenter");
                    this.delListener("sidebar_tabs_mouseenter");
                }
                this.isVisible = false;
            };
            if (!nodelay) this.hideTimer = setTimeout(onTimeout, UcfPrefs.prefs.v_hidedelay);
            else onTimeout();
        },
    },
};
toolbars.init();
